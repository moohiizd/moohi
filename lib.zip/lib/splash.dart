import 'package:flutter/material.dart';
import 'package:hkjb/selector.dart';
import 'package:splash_screen_view/SplashScreenView.dart';
import 'package:another_flutter_splash_screen/another_flutter_splash_screen.dart';


void main(){
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key : key);

  static const title_style = TextStyle(
      color: Colors.blue,
      fontWeight: FontWeight.w800,
      fontFamily: 'Irs',
      fontSize: 20,
      letterSpacing: 0.5
  );


  @override
  Widget build(BuildContext context) {

    Widget example = SplashScreenView(

      navigateRoute: Selector(),
      duration:  300,
      imageSize: 200,
      pageRouteTransition: PageRouteTransition.Normal,
      imageSrc: 'assets/splashscreen_image.png',
      speed: 100,
      text: "به فروشگاه خود خوش آمدید :)",
      textStyle: title_style,
      textType: TextType.TyperAnimatedText,
      backgroundColor: Colors.white,
    );




    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: example,
    );
  }
}
