


class SignupResponseModel{

  bool _error;
  String _message;

  SignupResponseModel(this._error , this._message);

  bool get error => _error;

  String get message => _message;

  set message(String value) {
    _message = value;
  }

  set error(bool value) {
    _error = value;
  }
}