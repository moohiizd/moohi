import 'dart:convert';
import 'dart:html';

import 'package:flutter/material.dart';
import 'package:hkjb/SignupResponseModel.dart';
import 'selector.dart';
import 'package:http/http.dart';



void main(){
  runApp(Signup());
}

class Signup extends StatefulWidget {
  const Signup({super.key});

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {


  static const title_style = TextStyle(
    color: Colors.blueAccent,
    fontFamily: "Irs",
    fontSize: 24,
    fontWeight: FontWeight.w800,
    letterSpacing: 0.5,

  );

  static const input_title = TextStyle(
    color: Colors.blueAccent,
    fontFamily: "Irs",
    fontSize: 16,
    fontWeight: FontWeight.w800,

  );

  static const  hint_text = TextStyle(
    color: Colors.black45,
    fontFamily: "Irs",
    fontSize: 16,
  );


  late String username , password , repeatpassword ;

  var _usernameContoller = TextEditingController();
  var _passwordContoller = TextEditingController();
  var _repeatpasswordContoller = TextEditingController();


  @override
  void initState() {

    username = "";
    password = "";
    repeatpassword = "";

    super.initState();

  }


  final _messengerKey = GlobalKey<ScaffoldMessengerState>();


  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      scaffoldMessengerKey: _messengerKey,

        home:Builder(
          builder: (context) {
            return Scaffold(
              appBar: AppBar(
                title: Text(
                  "ثبت نام",
                  style:
                  TextStyle(fontFamily: "Irs", fontSize: 20, color: Colors.black),
                ),

                centerTitle: true,
                leading: InkWell(
                  onTap: (){

                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => Selector() ));
                  },

                  child: Icon(
                    Icons.arrow_back,
                    color: Colors.black45,
                  ),
                ),
                backgroundColor: Colors.white,
                elevation: 0,
              ),
              body: SignupUI(),


            );
          }
        ));
  }


  Widget SignupUI(){
    return Center(
      child: Column(
        children: <Widget>[

          SizedBox(height: 30,),

          Text("فروشگاه آنلاین من ",
            style:title_style,
          ),

          SizedBox(
            height: 30,
          ),

          //کارد ویو دریافت اطلاعات

          Container(
            height: 380,
            margin: EdgeInsets.fromLTRB(30, 0, 30, 0),
            child:  Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
              elevation: 4,
              child: Center(
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      height: 30,
                    ),

                    //نام کاربری و متن دریافتی
                    Padding(

                      padding: EdgeInsets.fromLTRB(0, 0, 30, 0),
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: Text("نام کاربری", style: input_title,),

                      ),

                    ),

                    Padding(

                      padding: EdgeInsets.fromLTRB(40, 0, 40, 0),
                      child: TextField(
                        controller: _usernameContoller,
                        textAlign: TextAlign.center,
                        style: input_title,
                        decoration: InputDecoration(
                          hintText: "شماره موبایل",
                          hintStyle: hint_text,
                          suffixIcon: Icon(Icons.phone_android),

                        ),

                        onChanged: (value){

                          username = value;
                        },


                      ),
                    ),

                    SizedBox(height: 35,),

                    //کلمه عبور و متن دریافتی

                    Padding(

                      padding: EdgeInsets.fromLTRB(0, 0, 30, 0),
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          "کلمه عبور",
                          style: input_title,
                        ),
                      ),
                    ),

                    Padding(

                      padding: EdgeInsets.fromLTRB(40, 0, 40, 0),
                      child: TextField(

                        controller: _passwordContoller,

                        textAlign: TextAlign.center,
                        style: input_title,
                        decoration: InputDecoration(
                          hintText: "کلمه عبور",
                          hintStyle: hint_text,
                          suffixIcon: Icon(Icons.lock),
                        ),

                        onChanged: (value){

                          password = value;
                        },

                      ),
                    ),

                    SizedBox(height: 35,),

                    //تکرار کلمه عبور

                    Padding(

                      padding: EdgeInsets.fromLTRB(0, 0, 30, 0),
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          "تکرار کلمه عبور",
                          style: input_title,
                        ),
                      ),
                    ),

                    Padding(

                      padding: EdgeInsets.fromLTRB(40, 0, 40, 0),
                      child: TextField(

                        controller: _repeatpasswordContoller,

                        textAlign: TextAlign.center,
                        style: input_title,
                        decoration: InputDecoration(
                          hintText: "تکرار کلمه عبور",
                          hintStyle: hint_text,
                          suffixIcon: Icon(Icons.lock),
                        ),

                        onChanged: (value){

                          repeatpassword = value;

                        },

                      ),
                    ),

                  ],
                ),
              ),
            ),
          ),

          SizedBox(height: 40,),

          TextButton(
            onPressed:(){

              if(_usernameContoller.text == ""){

                //show msg
                ShowMySnackBar(context, "لطفا شماره موبایل خود را وارد فرمایید");

              }else if( _passwordContoller.text == ""){

                //show msg
                ShowMySnackBar(context, "لطفا کلمه عبور خود را وارد فرمایید");

              }else if( _repeatpasswordContoller.text == ""){

                //show msg
                ShowMySnackBar(context, "لطفا تکرار کلمه عبور را وارد فرمایید");

              }else if( _passwordContoller.text != _repeatpasswordContoller.text){

                //show msg
                ShowMySnackBar(context, "کلمه عبور و تکرارش تطابق ندارند");

              }else{

                //send request to server
                print("ok");
                sendSignupRequest(context: context , username:  _usernameContoller.text , password: _passwordContoller.text);
              }
            },
            child: Text('ثبت نام'),
            style:
            TextButton.styleFrom(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              fixedSize: Size(340, 60),
              primary: Colors.white,
              backgroundColor: Colors.blueAccent,
              elevation: 12,
              textStyle: TextStyle(fontSize: 22, fontFamily: "Irs" ),
            ),

          ),


        ],
      ),
    );
  }


  void sendSignupRequest({required BuildContext context , required String username , required String password}) async{

    var body = Map<String , dynamic>();

    body["username"] = username;
    body["password"] = password;

    Response response = await post(Uri.parse('https://cloud99.yourlinuxhost.com/app/signupforfinal.php'), body: body);

    if( response.statusCode == 200){

      //Result

      var signupJson = json.decode(utf8.decode(response.bodyBytes));
      var model = SignupResponseModel(signupJson["error"] , signupJson["message"]);

      if( model.error == false ){

        ShowMySnackBar(context, model.message);

      }else{

        ShowMySnackBar(context, model.message);
        //navigate to login page

      }


    }else{

      ShowMySnackBar(context, "خطایی در ارتباط با سرور رخ داده است");

    }
  }


  void ShowMySnackBar(BuildContext context , String message){

    _messengerKey.currentState!.showSnackBar(
      SnackBar(
        backgroundColor: Colors.black,
        content: Text(
            message, style: TextStyle(
            fontFamily: "Irs",
            fontSize: 17,
            color: Colors.white,
            fontWeight: FontWeight.bold,),
            textAlign: TextAlign.center),
        elevation: 5,
        duration: Duration(seconds: 10),
        action: SnackBarAction(
          label: 'تایید ',
          onPressed: (){},
          textColor: Colors.yellowAccent,
        ),


      )


    );

  }


}
