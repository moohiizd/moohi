import 'dart:io';

import 'package:flutter/material.dart';
import 'BasketInfo.dart';

import 'ListViewItems.dart';
import 'home.dart';
import 'package:zarinpal/zarinpal.dart';
import 'package:uni_links/uni_links.dart';



class ShoppingBasket extends StatefulWidget {
  const ShoppingBasket({super.key});

  @override
  State<ShoppingBasket> createState() => _ShoppingBasketState();
}

class _ShoppingBasketState extends State<ShoppingBasket> {


  static const title_style = TextStyle(
    color: Colors.black,
    fontFamily: "Irs",
    fontSize: 20,
    fontWeight: FontWeight.w800,
    letterSpacing: 0.5,

  );

  //استایل صفحه اصلی رنگ فونت و....
  static const input_title = TextStyle(
    color: Colors.blueAccent,
    fontFamily: "Irs",
    fontSize: 16,
    fontWeight: FontWeight.w800,

  );

  static const  hint_text = TextStyle(
    color: Colors.black45,
    fontFamily: "Irs",
    fontSize: 16,
  );


    PaymentRequest _paymentRequest = PaymentRequest()
      ..setIsSandBox(true) // if your application is in developer mode, then set the sandBox as True otherwise set sandBox as false
      ..setMerchantID("Zarinpal MerchantID")//شناسه زرین پال
      ..setCallbackURL("http://app.mystore"); //The c// allback can be an android scheme or a website URL, you and can pass any data with The callback for both scheme and  URL

  int total = 0;
  static String _paymentUrl='';


  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      debugShowCheckedModeBanner: false,
      home: Builder(
        builder: (context){
          return Scaffold(
            appBar: AppBar(
              title: Text(
                "سبد خرید شما",
                style:
                title_style,
              ),
              centerTitle: true,
              leading: InkWell(
                onTap: (){

                  Navigator.of(context).push(MaterialPageRoute(builder: (context) => Home() ));
                },
                child: Icon(
                  Icons.arrow_back,
                  color: Colors.black45,
                ),
              ),

              backgroundColor: Colors.white,
              elevation: 0,
            ),

            body: ShoppingBasketUI(context),

          );
        },
      ),

    );
  }

  Widget ShoppingBasketUI(context){

    return Stack(
// اندازه تصویر و مشخصات در سبد خرید

      children: <Widget>[

        Padding(
          padding:EdgeInsets.only(bottom: 50),
          child: ListView.builder(
            
            itemCount: BasketInfo.getTemplate().basketItems.length,
            itemBuilder: (context , postion){
              
              total = total+ int.parse(BasketInfo.getTemplate().basketItems[postion].price);

              return GestureDetector(

               child : Padding(
                   padding: EdgeInsets.fromLTRB(15, 10 , 15, 0),
                   child: ListViewItems(
                       BasketInfo.getTemplate().basketItems[postion] , removeItem as RemoveItem , postion),
                 ),








              );
            },
          ),

        ),

        Align(
          alignment: Alignment.bottomCenter,
          child: Material(

            color: Colors.red,
            child: InkWell(
              onTap: (){

                _paymentRequest.setAmount(total);
                _paymentRequest.setDescription("خرید از فروشگاه من");
                // Call Start payment
                ZarinPal().startPayment(_paymentRequest, (int? status, String? paymentGatewayUri){
                  if(status == 100)
                    _paymentUrl  = paymentGatewayUri!;// launch URL in browser
                    _launcherURL(_paymentUrl);
                });


                ZarinPal().verificationPayment("Status", "Authority Call back", _paymentRequest, (isPaymentSuccess,refID, paymentRequest){
                  if(isPaymentSuccess){
                    // Payment Is Success
                  }else{
                    // Error Print Status
                  }
                });

              },


              child: Container(

                width: MediaQuery.of(context).size.width,
                height: 60,
                child: Center(child: Text("پرداخت", style: TextStyle(color: Colors.white , fontFamily: "Irs", fontSize: 18),)),
              ),
            ),

          ),
        )


      ],


    );


  }


  void _launcherURL(String paymentUrl) async{

    if( ! await launch(_paymentUrl) ) throw 'Could not launch';
    exit(0);
  }


  void removeItem( int index){
    setState(() {
      BasketInfo.getTemplate().basketItems.removeAt(index);
    });
  }

  launch(String paymentUrl) {}

}
