import 'package:flutter/material.dart';
import 'package:hkjb/Product.dart';


typedef RemveItems(int index);

class ListViewItems extends StatefulWidget {



  Product _product;
  int _count=0;
  RemoveItem _RemoveItem;
  int _index;


  ListViewItems(this._product , this._RemoveItem , this._index);



  @override
  State<ListViewItems> createState() => _ListViewItemsState();
}

class RemoveItem {
}

class _ListViewItemsState extends State<ListViewItems> {

  static const title_style = TextStyle(
    color: Colors.black,
    fontFamily: "Irs",
    fontSize: 16,
    fontWeight: FontWeight.w800,
    letterSpacing: 0.5,

  );
  //استایل قیمت

  static const price_style = TextStyle(
    color: Colors.black,
    fontFamily: "Irs",
    fontSize: 14,
    fontWeight: FontWeight.w800,
    letterSpacing: 0.5,

  );
  //استایل متن تومان

  static const toman_style = TextStyle(
    color: Colors.black,
    fontFamily: "Irs",
    fontSize: 12,
    fontWeight: FontWeight.w800,
    letterSpacing: 0.5,

  );

  @override
  Widget build(BuildContext context) {
    return Card(

      shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
      elevation: 10,

      child: Container(
        height: 150,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          textDirection: TextDirection.rtl,
          mainAxisAlignment: MainAxisAlignment.start,

          children: <Widget>[
            //نشان دادن تصویر محصول در سبد خرید
            Padding(
              padding: EdgeInsets.all(20),
              child: Container(
                height: 130,
                width: 130,
                child: Image.asset(widget._product.image, width: 100, height: 100, fit: BoxFit.fill,),
              ),

            ),

            //عنوان محصول و قیمت

            Column(
              crossAxisAlignment: CrossAxisAlignment.end,

              children: <Widget>[

                Padding(
                    padding: EdgeInsets.fromLTRB(0, 20, 0, 0),
                  child: Container(
                    height: 60,
                    width: 180,
                    child: Text(widget._product.name , style: title_style, textAlign: TextAlign.end,),

                  ),
                ),

                Padding(
                    padding: EdgeInsets.fromLTRB(0, 30, 0, 0),
                  child: Container(
                    height: 20,
                    width: 180,

                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[

                        InkWell(
                          onTap: (){
                            widget._RemoveItem;
                          },
                            child: Icon(Icons.delete , color: Colors.red,)
                        ),

                        Row(

                          children: <Widget>[
                            
                            Text("تومان", style: toman_style,),
                            Text(widget._product.price , style: price_style,)
                          ],
                        )

                      ],
                    ),
                  ),
                ),
              ],
            )
          ],





        ),

      ),
        );


  }
}
