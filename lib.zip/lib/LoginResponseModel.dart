

class LoginResponseModel{

  bool _error;
  String _message;

  String _id;
  String _username;
  String _password;

  LoginResponseModel(
      this._error, this._message, this._id, this._username, this._password);

  String get password => _password;

  String get username => _username;

  String get id => _id;

  String get message => _message;

  bool get error => _error;

  set password(String value) {
    _password = value;
  }

  set username(String value) {
    _username = value;
  }

  set id(String value) {
    _id = value;
  }

  set message(String value) {
    _message = value;
  }

  set error(bool value) {
    _error = value;
  }
}