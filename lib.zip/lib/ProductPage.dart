import 'package:flutter/material.dart';
import 'package:hkjb/BasketInfo.dart';
import 'package:hkjb/Product.dart';
import 'package:hkjb/home.dart';
import 'package:hkjb/login.dart';


class ProductPage extends StatelessWidget {


  Product _product;
  ProductPage(this._product);



  static const title_style = TextStyle(
    color: Colors.black,
    fontFamily: "Irs",
    fontSize: 20,
    fontWeight: FontWeight.w800,
    letterSpacing: 0.5,

  );

  //استایل صفحه اصلی رنگ فونت و....
  static const input_title = TextStyle(
    color: Colors.blueAccent,
    fontFamily: "Irs",
    fontSize: 16,
    fontWeight: FontWeight.w800,

  );

  static const  hint_text = TextStyle(
    color: Colors.black45,
    fontFamily: "Irs",
    fontSize: 16,
  );


  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      debugShowCheckedModeBanner: false,
      home: Builder(
        builder: (context){
          return Scaffold(
            appBar: AppBar(
              title: Text(
                "جزئیات محصول",
                style:
                title_style,
              ),
              centerTitle: true,
              leading: InkWell(
                onTap: (){

                  Navigator.of(context).push(MaterialPageRoute(builder: (context) => Home() ));
                },
                child: Icon(
                  Icons.arrow_back,
                  color: Colors.black45,
                ),
              ),

              backgroundColor: Colors.white,
              elevation: 0,
            ),

            body: DescriptionUI(context),

          );
        },
      ),

    );
  }


 Widget DescriptionUI(context){

    //صفحه جزئیات محصول
    return Center(

      child: Column(

        children: <Widget>[

          SizedBox(height: 10,),

          Container(
            height: 170,
            width: MediaQuery.of(context).size.width/2,
            child: Image.asset(_product.image , fit: BoxFit.fill,),
          ),

          SizedBox(height: 10,),

          Container(
            height: 80,
            width: double.infinity,
            margin: EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: Card(
              //تشکیل مستطیل جزئبات
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
              elevation: 10,

              //درج نام محصول
              child: Center(

                child: Text(_product.name , style: title_style, textAlign: TextAlign.center,),

              ),


            ),
          ),

          SizedBox(height: 10,),


          Container(
            height: 220,
            width: double.infinity,
            margin: EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: Card(
              //تشکیل مستطیل جزئبات
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
              elevation: 10,

              //درج نام محصول
              child: Center(

                child: Text(_product.description , style: title_style, textAlign: TextAlign.center,),

              ),


            ),
          ),


          Expanded(
              child:Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                  child: InkWell(

                    onTap: (){


                      print("add to basket");
                      print("size before click = " + BasketInfo.getTemplate().basketItems.length.toString());
                      BasketInfo.getTemplate().basketItems.add(_product);
                      print("size after click = " + BasketInfo.getTemplate().basketItems.length.toString());

                    },

                    child: Container(
                      decoration: BoxDecoration(color: Colors.cyan, borderRadius: BorderRadius.all(Radius.circular(10))),
                      height: 60,
                      width: MediaQuery.of(context).size.width,
                      child: Center(


                        child: Text("افزودن به سبد خرید",
                        style: TextStyle(fontFamily: "Irs", fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),),
                      ),

                    ),

                  ),

                ),
              )
          )

        ],
      ),

    );

 }

}
