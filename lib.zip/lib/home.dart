import 'package:flutter/material.dart';
import 'package:flutter_image_slideshow/flutter_image_slideshow.dart';

import 'package:hkjb/Product.dart';
import 'ProductPage.dart';
import 'ShoppingBasket.dart';
import 'package:uni_links/uni_links.dart';
import 'package:http_parser/http_parser.dart';
import 'package:flutter/services.dart';





void main(){
  runApp(Home());
}



class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {

  static const title_style = TextStyle(
    color: Colors.cyan,
    fontFamily: "Irs",
    fontSize: 24,
    fontWeight: FontWeight.w800,
    letterSpacing: 0.5,

  );

  //استایل صفحه اصلی رنگ فونت و....
  static const input_title = TextStyle(
    color: Colors.blueAccent,
    fontFamily: "Irs",
    fontSize: 16,
    fontWeight: FontWeight.w800,

  );

  static const  hint_text = TextStyle(
    color: Colors.black45,
    fontFamily: "Irs",
    fontSize: 16,
  );

  int _selectedIndex = 0;

  

  final _messengerKey = GlobalKey<ScaffoldMessengerState>();

  String call_back = "";

  //لیست محصولات

  final List<Product> _items =[

    Product("1", "ساعت اسپرت مردانه", "2500000", "https://www.google.com/url?sa=i&url=https%3A%2F%2Ftorob.com%2Fp%2F2375dfa6-d6c8-404c-baa6-1c9319ef1a74%2F%25D8%25B3%25D8%25A7%25D8%25B9%25D8%25AA-%25D9%2587%25D9%2588%25D9%2585%25DB%258C%25D8%25B3-%25D8%25B2%25D9%2586%25D8%25A7%25D9%2586%25D9%2587-%25D8%25B3%25D8%25A7%25D8%25AF%25D9%2587-%25D8%25A8%25D9%2586%25D8%25AF-%25D8%25A7%25D8%25B3%25D8%25AA%25DB%258C%25D9%2584-%25D8%25B1%25D9%2586%25DA%25AF-%25D8%25B1%25D8%25B2%25DA%25AF%25D9%2584%25D8%25AF-%25D8%25B5%25D9%2581%25D8%25AD%25D9%2587-%25D8%25B1%25D8%25B2%25DA%25AF%25D9%2584%25D8%25AF%2F&psig=AOvVaw10t40pcnMqQafygM2XnLyd&ust=1726215704265000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCKCn3e_8vIgDFQAAAAAdAAAAABAJ", "توضیحات محصول 1"),
    Product("2", "ساعت زنانه", "3200000", "https://www.google.com/url?sa=i&url=https%3A%2F%2Ftorob.com%2Fp%2F2375dfa6-d6c8-404c-baa6-1c9319ef1a74%2F%25D8%25B3%25D8%25A7%25D8%25B9%25D8%25AA-%25D9%2587%25D9%2588%25D9%2585%25DB%258C%25D8%25B3-%25D8%25B2%25D9%2586%25D8%25A7%25D9%2586%25D9%2587-%25D8%25B3%25D8%25A7%25D8%25AF%25D9%2587-%25D8%25A8%25D9%2586%25D8%25AF-%25D8%25A7%25D8%25B3%25D8%25AA%25DB%258C%25D9%2584-%25D8%25B1%25D9%2586%25DA%25AF-%25D8%25B1%25D8%25B2%25DA%25AF%25D9%2584%25D8%25AF-%25D8%25B5%25D9%2581%25D8%25AD%25D9%2587-%25D8%25B1%25D8%25B2%25DA%25AF%25D9%2584%25D8%25AF%2F&psig=AOvVaw10t40pcnMqQafygM2XnLyd&ust=1726215704265000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCKCn3e_8vIgDFQAAAAAdAAAAABAJ", "توضیحات محصول 2"),
    Product("3", "ساعت مجلسی زنانه", "2600000", "https://www.google.com/url?sa=i&url=https%3A%2F%2Ftorob.com%2Fp%2F2375dfa6-d6c8-404c-baa6-1c9319ef1a74%2F%25D8%25B3%25D8%25A7%25D8%25B9%25D8%25AA-%25D9%2587%25D9%2588%25D9%2585%25DB%258C%25D8%25B3-%25D8%25B2%25D9%2586%25D8%25A7%25D9%2586%25D9%2587-%25D8%25B3%25D8%25A7%25D8%25AF%25D9%2587-%25D8%25A8%25D9%2586%25D8%25AF-%25D8%25A7%25D8%25B3%25D8%25AA%25DB%258C%25D9%2584-%25D8%25B1%25D9%2586%25DA%25AF-%25D8%25B1%25D8%25B2%25DA%25AF%25D9%2584%25D8%25AF-%25D8%25B5%25D9%2581%25D8%25AD%25D9%2587-%25D8%25B1%25D8%25B2%25DA%25AF%25D9%2584%25D8%25AF%2F&psig=AOvVaw10t40pcnMqQafygM2XnLyd&ust=1726215704265000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCKCn3e_8vIgDFQAAAAAdAAAAABAJ", "توضیحات محصول 3"),
    Product("4", "ساعت شیک مردانه", "1800000", "https://www.google.com/url?sa=i&url=https%3A%2F%2Ftorob.com%2Fp%2F2375dfa6-d6c8-404c-baa6-1c9319ef1a74%2F%25D8%25B3%25D8%25A7%25D8%25B9%25D8%25AA-%25D9%2587%25D9%2588%25D9%2585%25DB%258C%25D8%25B3-%25D8%25B2%25D9%2586%25D8%25A7%25D9%2586%25D9%2587-%25D8%25B3%25D8%25A7%25D8%25AF%25D9%2587-%25D8%25A8%25D9%2586%25D8%25AF-%25D8%25A7%25D8%25B3%25D8%25AA%25DB%258C%25D9%2584-%25D8%25B1%25D9%2586%25DA%25AF-%25D8%25B1%25D8%25B2%25DA%25AF%25D9%2584%25D8%25AF-%25D8%25B5%25D9%2581%25D8%25AD%25D9%2587-%25D8%25B1%25D8%25B2%25DA%25AF%25D9%2584%25D8%25AF%2F&psig=AOvVaw10t40pcnMqQafygM2XnLyd&ust=1726215704265000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCKCn3e_8vIgDFQAAAAAdAAAAABAJ", "توضیحات محصول 4"),

  ];

  Future<String?> initUniLink() async{
    try{
      final initialLink = await getInitialLink();
      return initialLink;

    }on PlatformException{

    }

  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
           title: Text("فروشگاه من", style: title_style,),
          centerTitle: true,
          backgroundColor: Colors.white,
          elevation: 5,
          actions: <Widget>[

            IconButton(
                onPressed:(){

                  Navigator.of(context).push(MaterialPageRoute(builder: (context) => ShoppingBasket() ));

                } , icon: Icon(Icons.shopping_cart,color: Colors.black54,))

          ],

        ),

        //اسلاید شو عکس ها
        body: MainUI(),


        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.white,
          elevation: 20,

          selectedFontSize: 14,
          selectedIconTheme: IconThemeData(color: Colors.teal, size: 30,),
          selectedItemColor: Colors.teal,
          selectedLabelStyle: input_title,

          unselectedIconTheme: IconThemeData(size: 30),
          unselectedLabelStyle: TextStyle(fontFamily: "Irs", fontWeight: FontWeight.bold),




          items: <BottomNavigationBarItem>[

            BottomNavigationBarItem(
                icon: Icon(Icons.settings),
              label: 'تنظیمات',

            ),


            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'صفحه اصلی',

            ),


            BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart),
              label: 'سبد خرید',

            ),

          ],

          currentIndex: _selectedIndex,

          onTap: _onItemTapped,

        ),

      ),
    );
  }

  Widget MainUI(){
    
    return Builder(builder: (context){

      return SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(

          children: <Widget>[

            ImageSlideshow(
                width: 450,
                height: 160,
                initialPage: 0,
                indicatorColor: Colors.white,
                indicatorBackgroundColor: Colors.grey,


                children: [

                  Image.asset('assets/slider1.jpg', fit: BoxFit.fill,),
                  Image.asset('assets/slider2.jpg', fit: BoxFit.fill,),
                  Image.asset('assets/slider3.webp', fit: BoxFit.fill,),
                  Image.asset('assets/slider4.jpg', fit: BoxFit.fill,),

                ],

              autoPlayInterval: 6000,
              isLoop: true,

            ),

            SizedBox(height: 10,),

            InkWell(
              onTap: (){},

              child: Container(
                height: 60,
                margin: EdgeInsets.fromLTRB(20, 0, 30, 0),
                child: Row(

                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,


                  children: <Widget>[
                    Icon(Icons.arrow_back_ios_new_rounded),
                    Text("پرفروش ترین محصولات", style: title_style,),
                  ],
                ),
              ),
            ),

            Container(
              height: 320,
              color: Colors.white38,
              child: Padding(
                padding: EdgeInsets.all(10),
                child: GridView.count(
                  scrollDirection: Axis.horizontal,
                  crossAxisCount: 1,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 15,
                  children: List.generate( _items.length , (int position) {

                      return generateItems(_items[position], context);


                }),

                ),
              ),
            ),

            SizedBox(height: 10,),

            Container(
              height: 170,
              width: 450,
              margin: EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                elevation: 10,
                child: Image.asset("assets/90544__2.jpg", fit: BoxFit.fill,),
                
              ),
            ),

            SizedBox(height: 10,),

            Container(
              height: 170,
              width: 450,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(

                    height: 120,
                    width: MediaQuery.of(context).size.width/2,
                    child: Card(

                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                      elevation: 10,
                      child: Image.asset("assets/groom_clock-39.jpg", fit: BoxFit.fill,),

                    ),
                  ),

                  SizedBox(height: 10,),

                  Container(

                    height: 140,
                    width: MediaQuery.of(context).size.width/2,
                    child: Card(

                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                      elevation: 10,
                      child: Image.asset("assets/93-103-1888.jpg", fit: BoxFit.fill,),

                    ),
                  ),

                  SizedBox(height: 10,),


                ],
              ),


            )


        ],


        ),
      );

    }

    );
    
  }

  void _onItemTapped(int index){

    setState(() {

      _selectedIndex = index;

    });

  }

}

Widget generateItems(Product product , BuildContext context){

  return Card(

    shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
    elevation: 10,
    child: InkWell(
      onTap: (){

        Navigator.of(context).push(MaterialPageRoute(builder: (context) => ProductPage(product) ));


      },
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            
            Container(
              
              width: 190,
              height: 170,
              child: Image.network(product.image , fit: BoxFit.fill,),
            ),

            SizedBox(height: 5,),

            Container(
              width: 220,
              height: 50,
              child: Text(
                product.name,
                textAlign: TextAlign.right,
                style: TextStyle(color: Colors.black, fontFamily: 'Irs', fontSize: 18),




              ),



            ),
            SizedBox(height: 5,),

            Divider(
              height: 1,
              color: Colors.grey,
              thickness: 1.4,
              endIndent: 15,
              indent: 15,
            ),

            SizedBox(height: 10,),

            Padding(
                padding: EdgeInsets.fromLTRB(30, 0, 0, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    
                    Text("تومان", style: TextStyle(fontFamily: 'Irs', color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold),),
                    Text(product.price, style: TextStyle(fontFamily: 'Irs', color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold),),
                  ],
                ),
            
            )


          ],
        ),
      ),


    ),

  );
}
