import 'package:flutter/material.dart';
import 'package:hkjb/login.dart';
import 'package:hkjb/signup.dart';


void main(){
  runApp(Selector());
}

class Selector extends StatefulWidget {
  const Selector({Key? key}) : super(key : key);

  @override
  State<Selector> createState() => _SelectorState();
}

class _SelectorState extends State<Selector> {

  static const title_style = TextStyle(
      color: Colors.blue,
      fontWeight: FontWeight.w800,
      fontFamily: 'Irs',
      fontSize: 22,
      letterSpacing: 0.5
  );


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.white,
        body: Center(
          child: Column(
            children: <Widget>[
              SizedBox(height: 80,),

              Text("خوش آمدید", style: title_style,),

              SizedBox(height: 80,),
              Image.asset("assets/welcome.gif", height: 250, width: 250,),
              SizedBox(height: 80,),
              TextButton(
                  onPressed: (){
                    
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => Login() ));
                    
                  },
                  child: Text("ورود"),
                  style: TextButton.styleFrom(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    fixedSize: Size(330, 60),
                    primary: Colors.white,
                    backgroundColor: Colors.blueAccent,
                    elevation: 10,
                    textStyle: TextStyle(fontSize: 22, fontFamily: 'Irs'),
                  ),
              ),
              SizedBox(
                height: 80,
              ),

              TextButton(
                onPressed: (){

                  Navigator.of(context).push(MaterialPageRoute(builder: (context) => Signup() ));

                },
                child: Text("ثبت نام"),
                style: TextButton.styleFrom(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  fixedSize: Size(330, 60),
                  primary: Colors.blueAccent,
                  backgroundColor: Colors.white,
                  elevation: 10,
                  textStyle: TextStyle(fontSize: 22, fontFamily: 'Irs'),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}
